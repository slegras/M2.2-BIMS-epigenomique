#' Package pour la formation EBAII
#' Contient les vignettes (les slides de cours), un jeu de données et les tutoriels 
#' @keywords internal
"_PACKAGE"